# Oaks Inventory App

Clean restart for The Oaks Laundry Center inventory app.

## Google Sheet
This app uses the clean Google Sheet:

https://docs.google.com/spreadsheets/d/1-vNEQ-jeqDEjr-0EbAc5DBfQd1x3UL0-0F6PW6FTlJg/edit

## App sections
- Fluff & Fold
- Snack Vending
- Laundry Vending
- Tracker
- Price Changes

There is no shared Restock/Machine dropdown in this build.

## Brand-new Apps Script setup
1. Go to https://script.google.com/
2. Create a NEW project.
3. Replace the default Code.gs with this repo's Code.gs.
4. Add an HTML file named exactly `Index`.
5. Paste this repo's Index.html into that file.
6. In Project Settings, enable "Show appsscript.json manifest file in editor".
7. Replace the manifest with this repo's appsscript.json.
8. Save.
9. Run `getState` once from the editor and authorize access when prompted.
10. Deploy > New deployment > Web app.
11. Execute as: Me.
12. Who has access: choose the level appropriate for your use.
13. Deploy and use the NEW /exec URL.

## Important
Do not reuse the old Apps Script deployment.
Do not use the old spreadsheet ID.
Do not add the old Restock/Machine dropdown code.

## GitHub
This repository is the source copy of the code. Unless you later wire GitHub to Apps Script with clasp/GitHub Actions, edits in GitHub do not automatically update the deployed Apps Script web app.

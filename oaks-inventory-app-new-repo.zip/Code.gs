/*
  THE OAKS INVENTORY APP
  Clean 5-tab build:
  - Fluff & Fold
  - Snack Vending
  - Laundry Vending
  - Price Change Log
  - Tracker
*/

const BOOK_ID = '1-vNEQ-jeqDEjr-0EbAc5DBfQd1x3UL0-0F6PW6FTlJg';

const SHEETS = {
  flufffold: 'Fluff & Fold',
  snacks: 'Snack Vending',
  laundry: 'Laundry Vending',
  prices: 'Price Change Log',
  tracker: 'Tracker'
};

function doGet() {
  return HtmlService
    .createHtmlOutputFromFile('Index')
    .setTitle('Oaks Inventory Tracker');
}

function book_() {
  return SpreadsheetApp.openById(BOOK_ID);
}

function sheet_(name) {
  const sh = book_().getSheetByName(name);
  if (!sh) throw new Error('Missing sheet: ' + name);
  return sh;
}

function whole_(value, allowZero) {
  const n = Number(value);
  if (
    value === '' ||
    value === null ||
    value === undefined ||
    !Number.isSafeInteger(n) ||
    n < (allowZero ? 0 : 1)
  ) {
    throw new Error('Enter a valid whole number.');
  }
  return n;
}

function money_(value) {
  const n = Number(String(value ?? '').replace(/[$,%\s,]/g, ''));
  return Number.isFinite(n) ? n : null;
}

function withLock_(fn) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    return fn();
  } finally {
    lock.releaseLock();
  }
}

function fluffFold_() {
  const sh = sheet_(SHEETS.flufffold);
  const last = sh.getLastRow();
  if (last < 5) return [];

  return sh
    .getRange(5, 1, last - 4, 17)
    .getDisplayValues()
    .map((v, i) => ({
      row: i + 5,
      item: v[0],
      category: v[1],
      vendor: v[2],
      unitCost: v[3],
      caseSize: v[4],
      casePrice: v[5],
      sellPrice: v[6],
      customerPrice: v[7],
      profit: v[8],
      margin: v[9],
      cleantieUnits: v[10],
      weeklySales: v[11],
      onHand: v[12],
      reorderPoint: v[13],
      needUnits: v[14],
      casesToBuy: v[15],
      action: v[16]
    }))
    .filter(x => x.item);
}

function vendingSlotMap_(sheetName) {
  const sh = sheet_(sheetName);
  const last = sh.getLastRow();
  if (last < 6) return [];

  const colA = sh.getRange(1, 1, last, 1).getDisplayValues().flat();
  const buyIndex = colA.findIndex(
    x => String(x).trim().toUpperCase() === 'BUYING / STOCK PLAN'
  );

  const slotEnd = buyIndex >= 0 ? buyIndex : last;
  if (slotEnd < 6) return [];

  return sh
    .getRange(6, 1, slotEnd - 5, 9)
    .getDisplayValues()
    .map((v, i) => ({
      row: i + 6,
      slot: v[0],
      item: v[1],
      vendPrice: v[2],
      unitCost: v[3],
      profit: v[4],
      margin: v[5],
      fullQty: v[6],
      supplier: v[7],
      note: v[8]
    }))
    .filter(x => x.item);
}

function vendingBuyPlan_(sheetName) {
  const sh = sheet_(sheetName);
  const last = sh.getLastRow();
  if (last < 1) return [];

  const colA = sh.getRange(1, 1, last, 1).getDisplayValues().flat();
  const buyIndex = colA.findIndex(
    x => String(x).trim().toUpperCase() === 'BUYING / STOCK PLAN'
  );

  if (buyIndex < 0) return [];

  const firstDataRow = buyIndex + 3;
  if (firstDataRow > last) return [];

  return sh
    .getRange(firstDataRow, 1, last - firstDataRow + 1, 11)
    .getDisplayValues()
    .map((v, i) => ({
      row: firstDataRow + i,
      item: v[0],
      vendor: v[1],
      unitCost: v[2],
      unitsPerCase: v[3],
      casePrice: v[4],
      onHand: v[5],
      target: v[6],
      needUnits: v[7],
      casesToBuy: v[8],
      estimatedCost: v[9],
      status: v[10]
    }))
    .filter(x => x.item);
}

function tracker_() {
  const sh = sheet_(SHEETS.tracker);
  const last = sh.getLastRow();
  if (last < 5) return [];

  return sh
    .getRange(5, 1, last - 4, 10)
    .getDisplayValues()
    .map(v => ({
      item: v[0],
      month: v[1],
      units: v[2],
      sales: v[3],
      unitCost: v[4],
      cogs: v[5],
      grossProfit: v[6],
      margin: v[7],
      weeklyUnits: v[8],
      action: v[9]
    }))
    .filter(x => x.item);
}

function priceChanges_() {
  const sh = sheet_(SHEETS.prices);
  const last = sh.getLastRow();
  if (last < 5) return [];

  return sh
    .getRange(5, 1, last - 4, 7)
    .getDisplayValues()
    .map((v, i) => ({
      row: i + 5,
      date: v[0],
      item: v[1],
      oldPrice: v[2],
      newPrice: v[3],
      change: v[4],
      reason: v[5],
      status: v[6]
    }))
    .filter(x => x.item);
}

function getState() {
  return {
    flufffold: fluffFold_(),
    snacks: {
      slots: vendingSlotMap_(SHEETS.snacks),
      buying: vendingBuyPlan_(SHEETS.snacks)
    },
    laundry: {
      slots: vendingSlotMap_(SHEETS.laundry),
      buying: vendingBuyPlan_(SHEETS.laundry)
    },
    tracker: tracker_(),
    priceChanges: priceChanges_()
  };
}

function saveFluffCount(form) {
  return withLock_(() => {
    if (!form || typeof form !== 'object') throw new Error('Invalid count.');

    const item = String(form.item || '');
    const onHand = whole_(form.onHand, true);
    const reorderPoint = whole_(form.reorderPoint, true);

    const found = fluffFold_().find(x => x.item === item);
    if (!found) throw new Error('Fluff & Fold item not found.');

    const sh = sheet_(SHEETS.flufffold);
    sh.getRange(found.row, 13, 1, 2).setValues([[onHand, reorderPoint]]);
    SpreadsheetApp.flush();

    return getState();
  });
}

function saveVendingCount(form) {
  return withLock_(() => {
    if (!form || typeof form !== 'object') {
      throw new Error('Invalid vending count.');
    }

    const group = String(form.group || '');
    if (group !== 'snacks' && group !== 'laundry') {
      throw new Error('Choose a valid vending group.');
    }

    const item = String(form.item || '');
    const onHand = whole_(form.onHand, true);
    const target = whole_(form.target, true);

    const sheetName =
      group === 'snacks'
        ? SHEETS.snacks
        : SHEETS.laundry;

    const found = vendingBuyPlan_(sheetName).find(x => x.item === item);
    if (!found) throw new Error('Vending item not found.');

    const sh = sheet_(sheetName);
    sh.getRange(found.row, 6, 1, 2).setValues([[onHand, target]]);
    SpreadsheetApp.flush();

    return getState();
  });
}

function saveSlot(form) {
  return withLock_(() => {
    if (!form || typeof form !== 'object') {
      throw new Error('Invalid vending update.');
    }

    const group = String(form.group || '');
    if (group !== 'snacks' && group !== 'laundry') {
      throw new Error('Choose a valid vending group.');
    }

    const slot = String(form.slot || '');
    const sheetName =
      group === 'snacks'
        ? SHEETS.snacks
        : SHEETS.laundry;

    const found = vendingSlotMap_(sheetName).find(x => x.slot === slot);
    if (!found) throw new Error('Slot not found.');

    const vendPrice = money_(form.vendPrice);
    if (vendPrice === null || vendPrice < 0) {
      throw new Error('Enter a valid vend price.');
    }

    const fullQty = whole_(form.fullQty, true);
    const sh = sheet_(sheetName);

    sh.getRange(found.row, 3).setValue(vendPrice);
    sh.getRange(found.row, 7).setValue(fullQty);
    SpreadsheetApp.flush();

    return getState();
  });
}

function addPriceChange(form) {
  return withLock_(() => {
    if (!form || typeof form !== 'object') {
      throw new Error('Invalid price change.');
    }

    const item = String(form.item || '').trim();
    if (!item) throw new Error('Choose an item.');

    const oldPrice = money_(form.oldPrice);
    const newPrice = money_(form.newPrice);

    if (oldPrice === null || newPrice === null) {
      throw new Error('Enter valid prices.');
    }

    const date = String(form.date || '');
    const reason = String(form.reason || '').slice(0, 500);
    const status = String(form.status || '').slice(0, 250);

    const sh = sheet_(SHEETS.prices);
    const row = sh.getLastRow() + 1;

    sh.getRange(row, 1, 1, 7).setValues([[
      date || new Date(),
      item,
      oldPrice,
      newPrice,
      '',
      reason,
      status
    ]]);

    sh.getRange(row, 5).setFormula(`=IFERROR(D${row}/C${row}-1,"")`);
    SpreadsheetApp.flush();

    return getState();
  });
}
